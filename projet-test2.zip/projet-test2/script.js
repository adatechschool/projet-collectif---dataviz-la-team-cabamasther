//COUNTDOWN

// Set the date we're counting down to
var countDownDate = new Date("Dec 25, 2021 08:00:00").getTime();
       
// Update the count down every 1 second
var x = setInterval(function() {

// Get today's date and time
var now = new Date().getTime();
    
// Find the distance between now and the count down date
var distance = countDownDate - now;
    
// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
// Output the result in an element with id="demo"
document.getElementById("demo").innerHTML = days + "d " + hours + "h "
+ minutes + "m " + seconds + "s ";
    
// If the count down is over, write some text 
if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
}
}, 1000);

var date = new Date();
            var hour = date.getHours();
            var minute = date.getMinutes();

            var leftHour = 23 - hour;
            var leftMinute = 59 - minute;

           // alert( "Be patient the drop will be in " + leftHour + " hours " + leftMinute + " minutes " );
        console.log(date)




        

//HORLOGE
        /*
* Starts any clocks using the user's local time
* From: cssanimation.rocks/clocks
*/
function initLocalClocks() {
// Get the local time using JS
var date = new Date;
var seconds = date.getSeconds();
var minutes = date.getMinutes();
var hours = date.getHours();
//document.getElementById("oclock1").append("");

// Create an object with each hand and it's angle in degrees
var hands = [
{
hand: 'hours',
angle: (hours * 30) + (minutes / 2)
},
{
hand: 'minutes',
angle: (minutes * 6)
},
{
hand: 'seconds',
angle: (seconds * 6)
}
];

// Loop through each of these hands to set their angle



//var time = new Date().getTime();
//$(document.body).bind("mousemove keypress", function(e) {
//  time = new Date().getTime();
// });



for (var j = 0; j < hands.length; j++) {
var elements = document.querySelectorAll('.' + hands[j].hand);
console.log(elements)
for (var k = 0; k < elements.length; k++) {
  elements[k].style.webkitTransform = 'rotateZ('+ hands[j].angle +'deg)';
  elements[k].style.transform = 'rotateZ('+ hands[j].angle +'deg)';
  // If this is a minute hand, note the seconds position (to calculate minute position later)
  if (hands[j].hand === 'minutes') {
    elements[k].parentNode.setAttribute('data-second-angle', hands[j + 1].angle);
  }
}
}
}



/*
* Set a timeout for the first minute hand movement (less than 1 minute), then rotate it every minute after that
*/
function setUpMinuteHands() {
// Find out how far into the minute we are
var containers = document.querySelectorAll('.minutes-container');
var secondAngle = containers[0].getAttribute("data-second-angle");
if (secondAngle > 0) {
// Set a timeout until the end of the current minute, to move the hand
var delay = (((360 - secondAngle) / 6) + 0.1) * 1000;
setTimeout(function() {
moveMinuteHands(containers);
}, delay);
}
}

/*
* Do the first minute's rotation
*/
function moveMinuteHands(containers) {
for (var i = 0; i < containers.length; i++) {
containers[i].style.webkitTransform = 'rotateZ(6deg)';
containers[i].style.transform = 'rotateZ(6deg)';
}
// Then continue with a 60 second interval
setInterval(function() {
for (var i = 0; i < containers.length; i++) {
if (containers[i].angle === undefined) {
  containers[i].angle = 12;
} else {
  containers[i].angle += 6;
}
containers[i].style.webkitTransform = 'rotateZ('+ containers[i].angle +'deg)';
containers[i].style.transform = 'rotateZ('+ containers[i].angle +'deg)';
}
}, 60000);
}

/*
* Move the second containers
*/
function moveSecondHands() {
var containers = document.querySelectorAll('.seconds-container');
setInterval(function() {
for (var i = 0; i < containers.length; i++) {
if (containers[i].angle === undefined) {
  containers[i].angle = 6;
} else {
  containers[i].angle += 6;
}
containers[i].style.webkitTransform = 'rotateZ('+ containers[i].angle +'deg)';
containers[i].style.transform = 'rotateZ('+ containers[i].angle +'deg)';
}
}, 1000);
}

// Initialise any local time clocks
initLocalClocks();
// Start the seconds container moving
moveSecondHands();
// Set the intial minute hand container transition, and then each subsequent step
setUpMinuteHands();
